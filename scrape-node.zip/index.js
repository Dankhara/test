import express from 'express';
import puppeteer from 'puppeteer-extra';
import createPuppeteerStealth from 'puppeteer-extra-plugin-stealth';

const puppeteerStealth = createPuppeteerStealth();
puppeteerStealth.enabledEvasions.delete('user-agent-override');
puppeteer.use(puppeteerStealth);

const app = express();
const port = 3000;

app.get('/scrape', async (req, res) => {
    try {

        var fname = req.query.fname;
        var lname = req.query.lname;
        var ppage = req.query.page || 1;

        if(!fname || !lname){
            return res.status(400).json({ error: "please give fname and lname. example:   http://localhost:3000/scrape?fname=john&lname=wick&page=1" });
        }

        const browser = await puppeteer.launch({
            headless: false,
            targetFilter: target => target.type() !== 'other'
        });

        const page = await browser.newPage();

        // Enable Chrome DevTools
        page.on('console', message => console.log(`Console: ${message.text()}`));
        page.on('pageerror', error => console.error(`Page error: ${error.message}`));
        page.on('requestfailed', request => console.error(`Request failed: ${request.url()}`));

        await page.goto(`https://truepeoplesearch.net/search?first_name=${fname}&last_name=${lname}&page=${ppage}`);
        await page.waitForSelector('#__NEXT_DATA__');

        // After the element with the ID 'someId' is present, extract data from it
        const data = await page.evaluate(() => {
            const element = document.querySelector('#__NEXT_DATA__');
            return element.textContent; // You can extract other data properties as needed
        });

        var parsedData = JSON.parse(data);

        var total = parsedData.props.pageProps.list_count;
        var peoples = parsedData.props.pageProps.people_list;

        await browser.close();
        return res.status(200).json({ peoples: peoples, total: total });
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});