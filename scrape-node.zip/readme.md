

Example : peoplesearch.com

install
----------------
npm install


run server
----------------
node index.js

example
---------------
change lname and fname as needed
http://localhost:3000/scrape?lname=wick&fname=john&page=1
http://localhost:3000/scrape?lname=wick&fname=john&page=2